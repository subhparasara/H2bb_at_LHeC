#include <iostream>
using std::cout;
using std::endl;

#include <fstream>
#include <sstream>

#include "HepMC/IO_GenEvent.h"
#include "HepMC/GenEvent.h"
#include "HepMC/GenVertex.h"

#include "Pythia8/Pythia.h"
#include "Pythia8Plugins/HepMC2.h"
using namespace Pythia8;

int main(int argc, char* argv[]) {

  if ( argc != 8 ) {
    cout << "wrong format..." << endl;
    return 1;
  }

  std::string indir(argv[1]);   // directory of input file
  std::string filename(argv[2]); // file name of input file
  std::string tdp(argv[5]); // decay mode for tau plus
  std::string tdm(argv[6]); // decay mode for tau minus
  int maxevt = atoi(argv[7]); // maximum number of events to run over

  // full input file name
  std::string infile=indir+"/"+filename;
  // Interface for conversion from Pythia8::Event to HepMC events
  HepMC::Pythia8ToHepMC converter;
  // Specify file where HepMC events will be stored.
  HepMC::IO_GenEvent ascii_io(argv[2], std::ios::out);

  // set up pythia
  Pythia pythia;
  pythia.readString("Beams:frameType = 4");
  pythia.readString("Beams:LHEF = "+infile);
  pythia.readString("SpaceShower:QEDshowerByL = on"); // for FSR from leptons
  pythia.readString("BeamRemnants:primordialKT = on");
    // Phase-space cut: minimal Q2 of process.
    //double Q2min     = 90.; 
    //pythia.settings.parm("PhaseSpace:Q2Min", Q2min);
    // Allow emissions up to the kinematical limit, since rate known to match well to matrix elements everywhere.
    pythia.readString("SpaceShower:pTmaxMatch = 2");
    pythia.readString("TimeShower:QEDshowerByL = on");
    // QED radiation off lepton not handled yet by the new procedure.
    pythia.readString("PDF:lepton = off");
    // Set dipole recoil on. Necessary for DIS + shower.
    pythia.readString("SpaceShower:dipoleRecoil = on");
    pythia.readString("PartonLevel:ISR = on"); // this is to turn off ISR - daniel added, 2015 dec 16
    //pythia.readString("PartonLevel:FSR = on"); // this is to turn off FSR - for test....
    pythia.readString("Check:event = off"); // Check for unphysical particles, or nonconserved charge or energy-momentum. # Added to check if the photo production works
    pythia.readString("LesHouches:matchInOut = off"); // momenta of the two incoming partons are recalculated from the sum of the outgoing final particles. 

  pythia.init();

  // now the event loop
  for (int iEvent = 0; ; ++iEvent){
    if ( maxevt>0 && iEvent>maxevt ) break;

    if ( iEvent%1000==0) 
      std::cout<<"Event: "<<iEvent<<endl;
    if (!pythia.next() ) continue; // this is where pythia does its stuff
    if ( pythia.info.atEndOfFile() ) break; // If failure because reached end of file then exit event loop.
    // Convert event record to HepMC (for tauola)
    HepMC::GenEvent * HepMCEvt = new HepMC::GenEvent();
    converter.fill_next_event( pythia, HepMCEvt );
    // Write the HepMC event to file. Done with it.
    ascii_io << HepMCEvt;

    if ( !(pythia.info.atEndOfFile()) ) std::cout<<"Number events written in the HEPMC = "<<HepMCEvt->event_number()<<" = "<<iEvent<<endl;
    // clean up
    delete HepMCEvt;

  } // end of event loop

  pythia.stat();
  // Done
  return EXIT_SUCCESS;
}
